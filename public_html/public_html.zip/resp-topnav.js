function myFunction() {
  var a = document.getElementById("myTopnav");
  "topnav" === a.className ? a.className += " responsive" : a.className = "topnav"
}