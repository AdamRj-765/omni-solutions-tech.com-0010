<?php

$email_to = "info@omni-solutions-tech.net"; // your email address
$email_subject = "OMNI-Ticket Submission"; // email subject line
$thankyou = "thankyou.htm"; // thank you page

// if you update the question on the form -
// you need to update the questions answer below
$antispam_answer = "25";

?>